const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits, canModerate } = require('../../utils/permissions');
const { moderationActionEmbed, errorEmbed } = require('../../components/embeds/moderationEmbeds');

module.exports = {
  name: 'kick',
  category: 'moderation',
  description: 'Kick a member from the server.',
  aliases: [],
  requiredPermission: PermissionFlagsBits.KickMembers,
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server.')
    .addUserOption((o) => o.setName('user').setDescription('Member to kick').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the kick').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(ctx) {
    const target = await ctx.getTargetMember('user', 0);
    if (!target) return ctx.reply({ embeds: [errorEmbed('Could not find that member.')] });

    const check = canModerate(ctx.member, target);
    if (!check.ok) return ctx.reply({ embeds: [errorEmbed(check.reason)] });

    if (!target.kickable) {
      return ctx.reply({ embeds: [errorEmbed("I don't have permission to kick that member.")] });
    }

    const reason = ctx.getReasonOrString('reason', 1);
    await target.kick(reason);

    return ctx.reply({
      embeds: [moderationActionEmbed({ action: '👋 Member Kicked', target: target.user, moderator: ctx.user, reason })],
    });
  },
};
