require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.GUILD_ID || null,
  prefix: process.env.PREFIX || '!',

  // Game tuning - tweak these to rebalance the economy without
  // touching command logic.
  game: {
    currencyName: 'Doubloons',
    currencyEmoji: '🐚',
    workMin: 50,
    workMax: 200,
    workCooldownMs: 60 * 60 * 1000, // 1 hour
    dailyAmount: 250,
    dailyCooldownMs: 24 * 60 * 60 * 1000, // 24 hours
    startingBalance: 100,
  },

  colors: {
    primary: 0xff8c42, // sunset orange
    success: 0x4caf50,
    danger: 0xe74c3c,
    warning: 0xf1c40f,
    info: 0x3aa6b9, // ocean blue
  },
};
