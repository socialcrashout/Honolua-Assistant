/**
 * Static game data for Honolua. Keeping this separate from logic
 * means rebalancing the game is just editing this file.
 */
const SHOP_ITEMS = [
  {
    id: 'poke_bowl',
    name: 'Poke Bowl',
    emoji: '🥣',
    price: 150,
    description: 'Fresh ahi poke over rice. A Honolua signature.',
    type: 'dish',
  },
  {
    id: 'plate_lunch',
    name: 'Plate Lunch',
    emoji: '🍱',
    price: 200,
    description: 'Two scoops rice, mac salad, and your choice of protein.',
    type: 'dish',
  },
  {
    id: 'shave_ice',
    name: 'Shave Ice',
    emoji: '🍧',
    price: 75,
    description: 'Rainbow-colored and always a hit on a hot day.',
    type: 'dish',
  },
  {
    id: 'spam_musubi',
    name: 'Spam Musubi',
    emoji: '🍙',
    price: 50,
    description: "The island's favorite grab-and-go snack.",
    type: 'dish',
  },
  {
    id: 'grill_upgrade',
    name: 'Charcoal Grill Upgrade',
    emoji: '🔥',
    price: 500,
    description: 'Boosts earnings from /work by making food taste better.',
    type: 'upgrade',
    workBonus: 25,
  },
  {
    id: 'food_truck',
    name: 'Second Food Truck',
    emoji: '🚚',
    price: 1200,
    description: 'Serve two locations at once. Big boost to /work payouts.',
    type: 'upgrade',
    workBonus: 60,
  },
];

function getItem(itemId) {
  return SHOP_ITEMS.find((item) => item.id === itemId.toLowerCase());
}

module.exports = { SHOP_ITEMS, getItem };
