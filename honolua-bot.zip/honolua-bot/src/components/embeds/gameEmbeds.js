const { baseEmbed } = require('./baseEmbed');
const config = require('../../config');
const { formatCurrency } = require('../../utils/formatters');
const { SHOP_ITEMS } = require('../../data/shopItems');

function balanceEmbed(user, target) {
  return baseEmbed({
    title: `🏝️ ${target.username}'s Restaurant Account`,
    color: config.colors.info,
  }).addFields(
    { name: 'Balance', value: formatCurrency(user.balance), inline: true },
    { name: 'Total Earned', value: formatCurrency(user.totalEarned), inline: true },
  ).setThumbnail(target.displayAvatarURL());
}

function workEmbed({ user, earned, line }) {
  return baseEmbed({
    title: '🍳 Shift complete!',
    color: config.colors.success,
    description: line,
  }).addFields(
    { name: 'Earned', value: formatCurrency(earned), inline: true },
    { name: 'New Balance', value: formatCurrency(user.balance), inline: true },
  );
}

function dailyEmbed({ user, amount }) {
  return baseEmbed({
    title: '🌅 Daily Bonus Claimed!',
    color: config.colors.success,
    description: `The owners of Honolua appreciate your loyalty.`,
  }).addFields(
    { name: 'Bonus', value: formatCurrency(amount), inline: true },
    { name: 'New Balance', value: formatCurrency(user.balance), inline: true },
  );
}

function cooldownEmbed(remaining, label = 'work another shift') {
  return baseEmbed({
    color: config.colors.warning,
    title: '⏳ Not yet!',
    description: `You need to rest before you can ${label} again.\nTry again in **${remaining}**.`,
  });
}

function shopEmbed() {
  const embed = baseEmbed({
    title: '🛒 Honolua Shop',
    color: config.colors.primary,
    description: `Buy dishes to flex on the menu, or upgrades to boost your \`/work\` earnings.\nUse \`/buy item:<name>\` or the menu below.`,
  });
  const dishes = SHOP_ITEMS.filter((i) => i.type === 'dish');
  const upgrades = SHOP_ITEMS.filter((i) => i.type === 'upgrade');

  embed.addFields({
    name: '🍽️ Dishes',
    value: dishes.map((i) => `${i.emoji} **${i.name}** — ${formatCurrency(i.price)}\n${i.description}`).join('\n\n'),
  });
  embed.addFields({
    name: '⭐ Upgrades',
    value: upgrades.map((i) => `${i.emoji} **${i.name}** — ${formatCurrency(i.price)}\n${i.description}`).join('\n\n'),
  });
  return embed;
}

function inventoryEmbed(target, user) {
  const entries = Object.entries(user.inventory || {});
  const embed = baseEmbed({
    title: `🎒 ${target.username}'s Inventory`,
    color: config.colors.info,
  });
  if (!entries.length) {
    embed.setDescription("Nothing here yet — try `/shop` and `/buy` something!");
    return embed;
  }
  const { getItem } = require('../../data/shopItems');
  embed.setDescription(
    entries
      .map(([itemId, qty]) => {
        const item = getItem(itemId);
        if (!item) return null;
        return `${item.emoji} **${item.name}** x${qty}`;
      })
      .filter(Boolean)
      .join('\n'),
  );
  return embed;
}

function leaderboardEmbed(guildName, entries, resolveTag) {
  const embed = baseEmbed({
    title: `🏆 ${guildName} Top Restaurateurs`,
    color: config.colors.primary,
  });
  if (!entries.length) {
    embed.setDescription('No one has earned anything yet. Be the first with `/work`!');
    return embed;
  }
  const medals = ['🥇', '🥈', '🥉'];
  embed.setDescription(
    entries
      .map((e, i) => `${medals[i] || `**${i + 1}.**`} ${resolveTag(e.userId)} — ${formatCurrency(e.balance)}`)
      .join('\n'),
  );
  return embed;
}

module.exports = {
  balanceEmbed,
  workEmbed,
  dailyEmbed,
  cooldownEmbed,
  shopEmbed,
  inventoryEmbed,
  leaderboardEmbed,
};
