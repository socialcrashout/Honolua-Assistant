const { PermissionFlagsBits } = require('discord.js');

function memberHasPermission(member, permission) {
  return Boolean(member?.permissions?.has(permission));
}

function canModerate(executorMember, targetMember) {
  if (!targetMember) return { ok: true };
  if (targetMember.id === executorMember.id) {
    return { ok: false, reason: "You can't do that to yourself." };
  }
  if (targetMember.guild.ownerId === targetMember.id) {
    return { ok: false, reason: "You can't moderate the server owner." };
  }
  const executorHighest = executorMember.roles.highest.position;
  const targetHighest = targetMember.roles.highest.position;
  if (targetHighest >= executorHighest && executorMember.guild.ownerId !== executorMember.id) {
    return { ok: false, reason: 'That member has an equal or higher role than you.' };
  }
  return { ok: true };
}

module.exports = { memberHasPermission, canModerate, PermissionFlagsBits };
