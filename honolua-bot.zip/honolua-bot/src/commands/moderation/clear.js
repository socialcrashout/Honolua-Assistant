const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits } = require('../../utils/permissions');
const { baseEmbed } = require('../../components/embeds/baseEmbed');
const { errorEmbed } = require('../../components/embeds/moderationEmbeds');
const config = require('../../config');

module.exports = {
  name: 'clear',
  category: 'moderation',
  description: 'Bulk delete recent messages in this channel.',
  aliases: ['purge'],
  requiredPermission: PermissionFlagsBits.ManageMessages,
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Bulk delete recent messages in this channel.')
    .addIntegerOption((o) => o.setName('amount').setDescription('Number of messages (1-100)').setMinValue(1).setMaxValue(100).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(ctx) {
    const amount = ctx.getIntegerOption('amount', 0);
    if (!amount || amount < 1 || amount > 100) {
      return ctx.reply({ embeds: [errorEmbed('Give a number between 1 and 100.')] });
    }

    const deleted = await ctx.channel.bulkDelete(amount, true).catch(() => null);
    if (!deleted) {
      return ctx.reply({ embeds: [errorEmbed('Could not delete messages (they may be older than 14 days).')] });
    }

    return ctx.reply({
      embeds: [
        baseEmbed({
          color: config.colors.success,
          title: '🧹 Channel Cleared',
          description: `Deleted **${deleted.size}** message(s).`,
        }),
      ],
    });
  },
};
