const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

/**
 * A reusable confirm/cancel button row. customId is namespaced
 * with an action + actor id so interactionCreate.js can route
 * clicks safely (and ignore clicks from people other than the
 * one who triggered the original command).
 */
function confirmCancelRow(action, actorId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`confirm_${action}_${actorId}`)
      .setLabel('Confirm')
      .setStyle(ButtonStyle.Success)
      .setEmoji('✅'),
    new ButtonBuilder()
      .setCustomId(`cancel_${action}_${actorId}`)
      .setLabel('Cancel')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('✖️'),
  );
}

module.exports = { confirmCancelRow };
