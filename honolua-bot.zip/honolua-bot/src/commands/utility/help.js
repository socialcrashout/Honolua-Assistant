const { SlashCommandBuilder } = require('discord.js');
const { helpEmbed } = require('../../components/embeds/utilityEmbeds');
const { helpCategoryRow } = require('../../components/buttons/helpButtons');
const { baseEmbed } = require('../../components/embeds/baseEmbed');
const config = require('../../config');

module.exports = {
  name: 'help',
  category: 'utility',
  description: 'List available commands.',
  aliases: ['commands', 'h'],
  data: new SlashCommandBuilder().setName('help').setDescription('List available commands.'),

  async execute(ctx) {
    const intro = baseEmbed({
      title: '🌺 Welcome to Honolua',
      color: config.colors.primary,
      description:
        "Honolua is a Hawaiian restaurant game bot — run your own island eatery, earn doubloons, and stock up on dishes and upgrades.\n\nPick a category below to see its commands.",
    });
    return ctx.reply({ embeds: [intro], components: [helpCategoryRow(ctx.user.id)] });
  },

  // Used by interactionCreate.js when the select menu changes.
  buildCategoryEmbed(client, category) {
    const commands = [...client.commands.values()].filter((c) => c.category === category);
    return helpEmbed(category[0].toUpperCase() + category.slice(1), commands);
  },
};
