const { SlashCommandBuilder } = require('discord.js');
const { SHOP_ITEMS } = require('../../data/shopItems');
const { purchaseItem } = require('../../utils/purchaseItem');
const { baseEmbed } = require('../../components/embeds/baseEmbed');
const { errorEmbed } = require('../../components/embeds/moderationEmbeds');
const { formatCurrency } = require('../../utils/formatters');
const config = require('../../config');

module.exports = {
  name: 'buy',
  category: 'game',
  description: 'Buy an item from the shop by name.',
  aliases: [],
  data: new SlashCommandBuilder()
    .setName('buy')
    .setDescription('Buy an item from the shop.')
    .addStringOption((o) =>
      o
        .setName('item')
        .setDescription('Item to buy')
        .setRequired(true)
        .addChoices(...SHOP_ITEMS.map((i) => ({ name: i.name, value: i.id }))),
    ),

  async execute(ctx) {
    const itemId = ctx.getStringOption('item', 0);
    if (!itemId) return ctx.reply({ embeds: [errorEmbed('Tell me what to buy, e.g. `/buy item:poke_bowl`.')] });

    const result = purchaseItem(ctx.guild.id, ctx.user.id, itemId.toLowerCase());
    if (!result.ok) return ctx.reply({ embeds: [errorEmbed(result.reason)] });

    return ctx.reply({
      embeds: [
        baseEmbed({
          color: config.colors.success,
          title: `${result.item.emoji} Purchased ${result.item.name}!`,
          description: `New balance: ${formatCurrency(result.user.balance)}`,
        }),
      ],
    });
  },
};
