const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database/db');
const { baseEmbed } = require('../../components/embeds/baseEmbed');
const { formatCurrency } = require('../../utils/formatters');
const { getItem } = require('../../data/shopItems');
const config = require('../../config');

module.exports = {
  name: 'profile',
  category: 'game',
  description: 'View a full restaurant profile: balance, upgrades, and dishes owned.',
  aliases: [],
  data: new SlashCommandBuilder()
    .setName('profile')
    .setDescription('View a full restaurant profile.')
    .addUserOption((o) => o.setName('user').setDescription('Member to check (defaults to you)').setRequired(false)),

  async execute(ctx) {
    const member = await ctx.getTargetMember('user', 0);
    const target = member?.user || ctx.user;
    const userData = db.getUser(ctx.guild.id, target.id);

    const upgrades = Object.entries(userData.inventory || {})
      .map(([id, qty]) => ({ item: getItem(id), qty }))
      .filter((e) => e.item?.type === 'upgrade');
    const dishCount = Object.entries(userData.inventory || {})
      .map(([id, qty]) => ({ item: getItem(id), qty }))
      .filter((e) => e.item?.type === 'dish')
      .reduce((sum, e) => sum + e.qty, 0);

    const embed = baseEmbed({
      title: `🏝️ ${target.username}'s Honolua Profile`,
      color: config.colors.primary,
    })
      .setThumbnail(target.displayAvatarURL())
      .addFields(
        { name: 'Balance', value: formatCurrency(userData.balance), inline: true },
        { name: 'Total Earned', value: formatCurrency(userData.totalEarned), inline: true },
        { name: 'Dishes Owned', value: `${dishCount}`, inline: true },
        {
          name: 'Upgrades',
          value: upgrades.length ? upgrades.map((e) => `${e.item.emoji} ${e.item.name} x${e.qty}`).join('\n') : 'None yet',
        },
      );

    return ctx.reply({ embeds: [embed] });
  },
};
