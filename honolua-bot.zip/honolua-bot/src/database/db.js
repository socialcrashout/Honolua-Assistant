const fs = require('fs');
const path = require('path');
const config = require('../config');

const DATA_DIR = path.join(__dirname, '..', '..', 'data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const WARNINGS_FILE = path.join(DATA_DIR, 'warnings.json');

function ensureFile(filePath, fallback) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify(fallback, null, 2));
  }
}

ensureFile(USERS_FILE, {});
ensureFile(WARNINGS_FILE, {});

function readJSON(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    console.error(`[db] Failed to read ${filePath}:`, err);
    return {};
  }
}

function writeJSON(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

/**
 * Users are keyed by `${guildId}-${userId}` so balances are
 * per-server, which keeps the game fair across different servers.
 */
function userKey(guildId, userId) {
  return `${guildId}-${userId}`;
}

function defaultUser() {
  return {
    balance: config.game.startingBalance,
    inventory: {}, // itemId -> quantity
    lastWork: 0,
    lastDaily: 0,
    totalEarned: 0,
  };
}

function getUser(guildId, userId) {
  const users = readJSON(USERS_FILE);
  const key = userKey(guildId, userId);
  if (!users[key]) {
    users[key] = defaultUser();
    writeJSON(USERS_FILE, users);
  }
  return users[key];
}

function saveUser(guildId, userId, userData) {
  const users = readJSON(USERS_FILE);
  users[userKey(guildId, userId)] = userData;
  writeJSON(USERS_FILE, users);
  return userData;
}

function updateUser(guildId, userId, updater) {
  const current = getUser(guildId, userId);
  const updated = updater({ ...current });
  return saveUser(guildId, userId, updated);
}

function getLeaderboard(guildId, limit = 10) {
  const users = readJSON(USERS_FILE);
  return Object.entries(users)
    .filter(([key]) => key.startsWith(`${guildId}-`))
    .map(([key, data]) => ({ userId: key.split('-')[1], ...data }))
    .sort((a, b) => b.balance - a.balance)
    .slice(0, limit);
}

function addWarning(guildId, userId, warning) {
  const warnings = readJSON(WARNINGS_FILE);
  const key = userKey(guildId, userId);
  if (!warnings[key]) warnings[key] = [];
  warnings[key].push(warning);
  writeJSON(WARNINGS_FILE, warnings);
  return warnings[key];
}

function getWarnings(guildId, userId) {
  const warnings = readJSON(WARNINGS_FILE);
  return warnings[userKey(guildId, userId)] || [];
}

module.exports = {
  getUser,
  saveUser,
  updateUser,
  getLeaderboard,
  addWarning,
  getWarnings,
};
