const { baseEmbed } = require('./baseEmbed');
const config = require('../../config');

function pingEmbed(latency, apiLatency) {
  return baseEmbed({ title: '🏓 Pong!', color: config.colors.info }).addFields(
    { name: 'Latency', value: `${latency}ms`, inline: true },
    { name: 'API Latency', value: `${apiLatency}ms`, inline: true },
  );
}

function userInfoEmbed(member, user) {
  return baseEmbed({
    title: `👤 ${user.tag}`,
    color: config.colors.info,
  })
    .setThumbnail(user.displayAvatarURL({ size: 256 }))
    .addFields(
      { name: 'ID', value: user.id, inline: true },
      { name: 'Bot?', value: user.bot ? 'Yes' : 'No', inline: true },
      { name: 'Joined Server', value: member ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>` : 'Unknown', inline: true },
      { name: 'Account Created', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
      {
        name: 'Roles',
        value: member ? member.roles.cache.filter((r) => r.id !== member.guild.id).map((r) => r.toString()).join(' ') || 'None' : 'Unknown',
      },
    );
}

function serverInfoEmbed(guild) {
  return baseEmbed({
    title: `🏝️ ${guild.name}`,
    color: config.colors.info,
  })
    .setThumbnail(guild.iconURL() || null)
    .addFields(
      { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
      { name: 'Members', value: `${guild.memberCount}`, inline: true },
      { name: 'Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:R>`, inline: true },
      { name: 'Roles', value: `${guild.roles.cache.size}`, inline: true },
      { name: 'Channels', value: `${guild.channels.cache.size}`, inline: true },
      { name: 'Boost Level', value: `${guild.premiumTier}`, inline: true },
    );
}

function avatarEmbed(user) {
  return baseEmbed({ title: `${user.tag}'s avatar`, color: config.colors.info }).setImage(
    user.displayAvatarURL({ size: 1024 }),
  );
}

function helpEmbed(category, commands) {
  const embed = baseEmbed({
    title: `🌺 Honolua Help${category ? ` — ${category}` : ''}`,
    color: config.colors.primary,
    description: 'Use the menu below to browse command categories.\nSlash commands (`/`) and prefix commands (`' + config.prefix + '`) both work.',
  });
  commands.forEach((cmd) => {
    embed.addFields({ name: `/${cmd.name}`, value: cmd.description || 'No description.' });
  });
  return embed;
}

module.exports = { pingEmbed, userInfoEmbed, serverInfoEmbed, avatarEmbed, helpEmbed };
