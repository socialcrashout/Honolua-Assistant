const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { SHOP_ITEMS } = require('../../data/shopItems');

/**
 * Lets a user pick a shop item from a dropdown instead of typing
 * the exact item name. The interactionCreate handler reads the
 * selected value and runs the same purchase logic as /buy.
 */
function shopSelectRow(actorId) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`shop_select_${actorId}`)
    .setPlaceholder('Choose an item to buy...')
    .addOptions(
      SHOP_ITEMS.map((item) => ({
        label: item.name,
        description: `${item.price} doubloons — ${item.description}`.slice(0, 100),
        value: item.id,
        emoji: item.emoji,
      })),
    );
  return new ActionRowBuilder().addComponents(menu);
}

module.exports = { shopSelectRow };
