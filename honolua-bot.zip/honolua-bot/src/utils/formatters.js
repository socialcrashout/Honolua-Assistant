const config = require('../config');

function formatCurrency(amount) {
  return `${config.game.currencyEmoji} **${amount.toLocaleString()}** ${config.game.currencyName}`;
}

function timeUntil(targetTimestampMs) {
  const remaining = targetTimestampMs - Date.now();
  if (remaining <= 0) return null;
  const mins = Math.ceil(remaining / 60000);
  if (mins < 60) return `${mins}m`;
  const hours = Math.floor(mins / 60);
  const remMins = mins % 60;
  return `${hours}h ${remMins}m`;
}

module.exports = { formatCurrency, timeUntil };
