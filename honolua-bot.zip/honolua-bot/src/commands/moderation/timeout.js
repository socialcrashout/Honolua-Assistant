const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits, canModerate } = require('../../utils/permissions');
const { parseDuration, formatDuration } = require('../../utils/parseDuration');
const { moderationActionEmbed, errorEmbed } = require('../../components/embeds/moderationEmbeds');

module.exports = {
  name: 'timeout',
  category: 'moderation',
  description: 'Time out a member so they temporarily lose send/speak permissions.',
  aliases: ['mute'],
  requiredPermission: PermissionFlagsBits.ModerateMembers,
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Time out a member.')
    .addUserOption((o) => o.setName('user').setDescription('Member to time out').setRequired(true))
    .addStringOption((o) => o.setName('duration').setDescription('e.g. 10m, 1h, 1d').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the timeout').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(ctx) {
    const target = await ctx.getTargetMember('user', 0);
    if (!target) return ctx.reply({ embeds: [errorEmbed('Could not find that member.')] });

    const check = canModerate(ctx.member, target);
    if (!check.ok) return ctx.reply({ embeds: [errorEmbed(check.reason)] });

    const durationRaw = ctx.getStringOption('duration', 1);
    const ms = parseDuration(durationRaw);
    if (!ms || ms > 28 * 24 * 60 * 60 * 1000) {
      return ctx.reply({ embeds: [errorEmbed('Give a valid duration like `10m`, `1h`, or `1d` (max 28 days).')] });
    }

    const reason = ctx.isSlash ? ctx.getStringOption('reason', -1) || 'No reason provided.' : ctx.getReasonOrString('reason', 2);

    if (!target.moderatable) {
      return ctx.reply({ embeds: [errorEmbed("I don't have permission to time out that member.")] });
    }

    await target.timeout(ms, reason);

    return ctx.reply({
      embeds: [
        moderationActionEmbed({
          action: '🔇 Member Timed Out',
          target: target.user,
          moderator: ctx.user,
          reason,
          extra: `Duration: ${formatDuration(ms)}`,
        }),
      ],
    });
  },
};
