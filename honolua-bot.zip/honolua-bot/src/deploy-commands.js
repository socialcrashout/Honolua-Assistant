const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');
const config = require('./config');

if (!config.token || !config.clientId) {
  console.error('Missing DISCORD_TOKEN or CLIENT_ID in your .env file.');
  process.exit(1);
}

function collectSlashData() {
  const commandsDir = path.join(__dirname, 'commands');
  const categories = fs.readdirSync(commandsDir);
  const data = [];

  for (const category of categories) {
    const categoryPath = path.join(commandsDir, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;
    for (const file of fs.readdirSync(categoryPath).filter((f) => f.endsWith('.js'))) {
      const command = require(path.join(categoryPath, file));
      if (command?.data) data.push(command.data.toJSON());
    }
  }
  return data;
}

(async () => {
  const commands = collectSlashData();
  const rest = new REST().setToken(config.token);

  try {
    if (config.guildId) {
      await rest.put(Routes.applicationGuildCommands(config.clientId, config.guildId), { body: commands });
      console.log(`✅ Registered ${commands.length} guild slash commands (instant, single server).`);
    } else {
      await rest.put(Routes.applicationCommands(config.clientId), { body: commands });
      console.log(`✅ Registered ${commands.length} global slash commands (can take up to 1 hour to show up).`);
    }
  } catch (err) {
    console.error('Failed to register slash commands:', err);
  }
})();
