const UNIT_MS = {
  s: 1000,
  m: 60 * 1000,
  h: 60 * 60 * 1000,
  d: 24 * 60 * 60 * 1000,
};

/**
 * Parses shorthand durations like "10m", "2h", "1d" into milliseconds.
 * Returns null if the string can't be parsed.
 */
function parseDuration(input) {
  if (!input) return null;
  const match = /^(\d+)\s*(s|m|h|d)$/i.exec(input.trim());
  if (!match) return null;
  const [, amountStr, unit] = match;
  const amount = parseInt(amountStr, 10);
  return amount * UNIT_MS[unit.toLowerCase()];
}

function formatDuration(ms) {
  const days = Math.floor(ms / UNIT_MS.d);
  const hours = Math.floor((ms % UNIT_MS.d) / UNIT_MS.h);
  const mins = Math.floor((ms % UNIT_MS.h) / UNIT_MS.m);
  const parts = [];
  if (days) parts.push(`${days}d`);
  if (hours) parts.push(`${hours}h`);
  if (mins) parts.push(`${mins}m`);
  return parts.length ? parts.join(' ') : '< 1m';
}

module.exports = { parseDuration, formatDuration };
