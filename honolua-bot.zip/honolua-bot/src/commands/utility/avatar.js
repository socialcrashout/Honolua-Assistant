const { SlashCommandBuilder } = require('discord.js');
const { avatarEmbed } = require('../../components/embeds/utilityEmbeds');

module.exports = {
  name: 'avatar',
  category: 'utility',
  description: "View a member's avatar.",
  aliases: ['av', 'pfp'],
  data: new SlashCommandBuilder()
    .setName('avatar')
    .setDescription("View a member's avatar.")
    .addUserOption((o) => o.setName('user').setDescription('Member to look up (defaults to you)').setRequired(false)),

  async execute(ctx) {
    const member = await ctx.getTargetMember('user', 0);
    const user = member?.user || ctx.user;
    return ctx.reply({ embeds: [avatarEmbed(user)] });
  },
};
