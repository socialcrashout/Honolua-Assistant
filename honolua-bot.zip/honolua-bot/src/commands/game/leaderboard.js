const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database/db');
const { leaderboardEmbed } = require('../../components/embeds/gameEmbeds');

module.exports = {
  name: 'leaderboard',
  category: 'game',
  description: 'See the top earners on this server.',
  aliases: ['lb', 'top'],
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('See the top earners on this server.'),

  async execute(ctx) {
    const entries = db.getLeaderboard(ctx.guild.id, 10);
    const resolveTag = (userId) => `<@${userId}>`;
    return ctx.reply({ embeds: [leaderboardEmbed(ctx.guild.name, entries, resolveTag)] });
  },
};
