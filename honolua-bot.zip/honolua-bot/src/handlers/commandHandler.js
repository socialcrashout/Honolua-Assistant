const fs = require('fs');
const path = require('path');
const { Collection } = require('discord.js');

/**
 * Recursively loads every command file under /commands into a
 * Collection keyed by command name, and a second Collection keyed
 * by alias -> command name for prefix-command lookup.
 */
function loadCommands(client) {
  client.commands = new Collection();
  client.aliases = new Collection();

  const commandsDir = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsDir);

  for (const category of categories) {
    const categoryPath = path.join(commandsDir, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter((f) => f.endsWith('.js'));
    for (const file of files) {
      const command = require(path.join(categoryPath, file));
      if (!command?.name || !command?.execute) {
        console.warn(`[commandHandler] Skipping invalid command file: ${file}`);
        continue;
      }
      client.commands.set(command.name, command);
      (command.aliases || []).forEach((alias) => client.aliases.set(alias, command.name));
    }
  }

  console.log(`[commandHandler] Loaded ${client.commands.size} commands.`);
}

module.exports = { loadCommands };
