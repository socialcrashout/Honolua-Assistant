const { SlashCommandBuilder } = require('discord.js');
const { shopEmbed } = require('../../components/embeds/gameEmbeds');

module.exports = {
  name: 'menu',
  category: 'game',
  description: "View Honolua's menu (alias of /shop).",
  aliases: [],
  data: new SlashCommandBuilder().setName('menu').setDescription("View Honolua's menu."),

  async execute(ctx) {
    return ctx.reply({ embeds: [shopEmbed()] });
  },
};
