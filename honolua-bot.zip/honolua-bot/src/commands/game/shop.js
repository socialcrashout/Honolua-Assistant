const { SlashCommandBuilder } = require('discord.js');
const { shopEmbed } = require('../../components/embeds/gameEmbeds');
const { shopSelectRow } = require('../../components/buttons/shopButtons');

module.exports = {
  name: 'shop',
  category: 'game',
  description: 'Browse the Honolua shop for dishes and upgrades.',
  aliases: ['store'],
  data: new SlashCommandBuilder().setName('shop').setDescription('Browse the Honolua shop.'),

  async execute(ctx) {
    return ctx.reply({ embeds: [shopEmbed()], components: [shopSelectRow(ctx.user.id)] });
  },
};
