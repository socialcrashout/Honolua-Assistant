const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database/db');
const { balanceEmbed } = require('../../components/embeds/gameEmbeds');

module.exports = {
  name: 'balance',
  category: 'game',
  description: 'Check your (or someone else\'s) restaurant balance.',
  aliases: ['bal', 'cash'],
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your restaurant balance.')
    .addUserOption((o) => o.setName('user').setDescription('Member to check (defaults to you)').setRequired(false)),

  async execute(ctx) {
    const member = await ctx.getTargetMember('user', 0);
    const target = member?.user || ctx.user;
    const userData = db.getUser(ctx.guild.id, target.id);
    return ctx.reply({ embeds: [balanceEmbed(userData, target)] });
  },
};
