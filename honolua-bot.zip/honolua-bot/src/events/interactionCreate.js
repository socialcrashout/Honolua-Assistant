const { CommandContext } = require('../utils/CommandContext');
const { errorEmbed } = require('../components/embeds/moderationEmbeds');
const { baseEmbed } = require('../components/embeds/baseEmbed');
const { purchaseItem } = require('../utils/purchaseItem');
const { formatCurrency } = require('../utils/formatters');
const config = require('../config');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) return handleSlashCommand(interaction, client);
    if (interaction.isStringSelectMenu()) return handleSelectMenu(interaction, client);
    // Button handling is stubbed here for future confirm/cancel flows.
  },
};

async function handleSlashCommand(interaction, client) {
  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  if (command.requiredPermission && !interaction.member.permissions.has(command.requiredPermission)) {
    return interaction.reply({ embeds: [errorEmbed("You don't have permission to use that command.")], ephemeral: true });
  }

  const ctx = new CommandContext({ interaction, client });

  try {
    await command.execute(ctx);
  } catch (err) {
    console.error(`[interactionCreate] Error running /${interaction.commandName}:`, err);
    const payload = { embeds: [errorEmbed('Something went wrong running that command.')], ephemeral: true };
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp(payload).catch(() => {});
    } else {
      await interaction.reply(payload).catch(() => {});
    }
  }
}

async function handleSelectMenu(interaction, client) {
  // customIds are formatted as `${prefix}_select_${actorId}`
  const ownerId = interaction.customId.split('_').pop();
  if (interaction.user.id !== ownerId) {
    return interaction.reply({ content: "This menu isn't yours — run the command yourself!", ephemeral: true });
  }

  if (interaction.customId.startsWith('shop_select_')) {
    const itemId = interaction.values[0];
    const result = purchaseItem(interaction.guild.id, interaction.user.id, itemId);
    if (!result.ok) {
      return interaction.reply({ embeds: [errorEmbed(result.reason)], ephemeral: true });
    }
    return interaction.reply({
      embeds: [
        baseEmbed({
          color: config.colors.success,
          title: `${result.item.emoji} Purchased ${result.item.name}!`,
          description: `New balance: ${formatCurrency(result.user.balance)}`,
        }),
      ],
      ephemeral: true,
    });
  }

  if (interaction.customId.startsWith('help_select_')) {
    const category = interaction.values[0];
    const helpCommand = client.commands.get('help');
    const embed = helpCommand.buildCategoryEmbed(client, category);
    return interaction.update({ embeds: [embed] });
  }
}
