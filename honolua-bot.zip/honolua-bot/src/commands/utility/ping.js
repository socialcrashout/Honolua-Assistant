const { SlashCommandBuilder } = require('discord.js');
const { pingEmbed } = require('../../components/embeds/utilityEmbeds');

module.exports = {
  name: 'ping',
  category: 'utility',
  description: "Check the bot's latency.",
  aliases: ['pong'],
  data: new SlashCommandBuilder().setName('ping').setDescription("Check the bot's latency."),

  async execute(ctx) {
    const sent = await ctx.reply({ content: 'Pinging...' });
    const latency = ctx.isSlash
      ? sent.createdTimestamp - ctx.interaction.createdTimestamp
      : sent.createdTimestamp - ctx.message.createdTimestamp;
    const apiLatency = Math.round(ctx.client.ws.ping);

    const payload = { content: null, embeds: [pingEmbed(latency, apiLatency)] };
    if (ctx.isSlash) {
      return ctx.interaction.editReply(payload);
    }
    return sent.edit(payload);
  },
};
