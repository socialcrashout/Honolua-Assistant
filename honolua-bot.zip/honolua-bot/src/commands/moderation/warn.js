const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits, canModerate } = require('../../utils/permissions');
const { moderationActionEmbed, warnListEmbed, errorEmbed } = require('../../components/embeds/moderationEmbeds');
const db = require('../../database/db');

module.exports = {
  name: 'warn',
  category: 'moderation',
  description: 'Warn a member, or view warnings with the warnings subcommand.',
  aliases: [],
  requiredPermission: PermissionFlagsBits.ModerateMembers,
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn a member.')
    .addUserOption((o) => o.setName('user').setDescription('Member to warn').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(ctx) {
    const target = await ctx.getTargetMember('user', 0);
    if (!target) return ctx.reply({ embeds: [errorEmbed('Could not find that member.')] });

    const check = canModerate(ctx.member, target);
    if (!check.ok) return ctx.reply({ embeds: [errorEmbed(check.reason)] });

    const reason = ctx.getReasonOrString('reason', 1);

    db.addWarning(ctx.guild.id, target.id, {
      reason,
      moderatorTag: ctx.user.tag,
      timestamp: Date.now(),
    });

    return ctx.reply({
      embeds: [moderationActionEmbed({ action: '⚠️ Member Warned', target: target.user, moderator: ctx.user, reason })],
    });
  },
};
