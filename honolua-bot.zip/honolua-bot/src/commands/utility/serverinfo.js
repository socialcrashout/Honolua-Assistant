const { SlashCommandBuilder } = require('discord.js');
const { serverInfoEmbed } = require('../../components/embeds/utilityEmbeds');

module.exports = {
  name: 'serverinfo',
  category: 'utility',
  description: 'View information about this server.',
  aliases: ['server'],
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('View information about this server.'),

  async execute(ctx) {
    return ctx.reply({ embeds: [serverInfoEmbed(ctx.guild)] });
  },
};
