# 🌺 Honolua

A Discord bot themed around **Honolua**, a Hawaiian restaurant — run your own
island eatery, earn doubloons, buy dishes and upgrades, and keep your server
in order with a full set of moderation commands.

Every command works **both as a slash command (`/`) and a prefix command
(`!`)** from the same file — there's no duplicated logic between the two.

## Features

- 🍽️ **Restaurant game**: `/work`, `/daily`, `/shop`, `/buy`, `/inventory`,
  `/profile`, `/leaderboard`, `/menu`
- 🛡️ **Moderation**: `/timeout`, `/kick`, `/ban`, `/unban`, `/warn`,
  `/warnings`, `/clear`
- 🔧 **Utility**: `/help`, `/ping`, `/userinfo`, `/serverinfo`, `/avatar`
- Classic embeds + buttons/select menus throughout (no Components V2)
- Every command, embed, and button is its own small file — easy to add to
  or rebalance without touching the rest of the bot
- Simple JSON file storage, no database server to set up

## Project structure

```
src/
  index.js              entry point
  config.js             env + game-balance settings
  deploy-commands.js    registers slash commands with Discord
  database/db.js        JSON file storage for balances/warnings
  data/shopItems.js      static game data (menu/shop)
  handlers/             loads commands & events into the client
  events/               ready, messageCreate, interactionCreate
  commands/
    game/               restaurant economy commands
    moderation/         mod commands
    utility/            general-purpose commands
  components/
    embeds/             reusable embed builders
    buttons/             reusable button/select-menu rows
  utils/                shared helpers (permissions, durations, context)
```

## Setup

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Create a bot application**
   - Go to https://discord.com/developers/applications → New Application
   - Bot tab → Reset Token → copy it
   - Under **Privileged Gateway Intents**, enable **Server Members Intent**
     and **Message Content Intent** (needed for prefix commands and
     userinfo/timeout to work properly)

3. **Configure your environment**
   ```bash
   cp .env.example .env
   ```
   Fill in:
   - `DISCORD_TOKEN` — your bot token
   - `CLIENT_ID` — your application ID (same page as the token)
   - `GUILD_ID` *(optional, recommended while developing)* — your test
     server's ID, so slash commands register instantly instead of taking
     up to an hour
   - `PREFIX` — defaults to `!`

4. **Invite the bot to your server**
   Generate an invite link in the Discord Developer Portal under
   OAuth2 → URL Generator, with scopes `bot` and `applications.commands`,
   and these bot permissions at minimum: Manage Messages, Moderate
   Members, Kick Members, Ban Members, Send Messages, Embed Links.

5. **Register slash commands**
   ```bash
   npm run deploy
   ```

6. **Run the bot**
   ```bash
   npm start
   ```
   (or `npm run dev` to auto-restart on file changes)

## Rebalancing the game

All the numbers that matter — work payout range, cooldowns, daily bonus,
shop prices, upgrade bonuses — live in `src/config.js` and
`src/data/shopItems.js`. You shouldn't need to touch command logic to
change how the economy feels.

## Adding a new command

1. Drop a new file in `src/commands/<game|moderation|utility>/`
2. Export `{ name, category, description, aliases, data, execute(ctx) }`
3. That's it — the command handler picks it up automatically, for both
   slash and prefix usage, the next time the bot starts.
