const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database/db');
const config = require('../../config');
const { dailyEmbed, cooldownEmbed } = require('../../components/embeds/gameEmbeds');
const { timeUntil } = require('../../utils/formatters');

module.exports = {
  name: 'daily',
  category: 'game',
  description: 'Claim your daily doubloon bonus.',
  aliases: [],
  data: new SlashCommandBuilder().setName('daily').setDescription('Claim your daily doubloon bonus.'),

  async execute(ctx) {
    const userData = db.getUser(ctx.guild.id, ctx.user.id);
    const now = Date.now();
    const nextAvailable = userData.lastDaily + config.game.dailyCooldownMs;

    if (now < nextAvailable) {
      const remaining = timeUntil(nextAvailable);
      return ctx.reply({ embeds: [cooldownEmbed(remaining, 'claim your daily bonus')] });
    }

    const amount = config.game.dailyAmount;
    const updated = db.updateUser(ctx.guild.id, ctx.user.id, (u) => ({
      ...u,
      balance: u.balance + amount,
      totalEarned: u.totalEarned + amount,
      lastDaily: now,
    }));

    return ctx.reply({ embeds: [dailyEmbed({ user: updated, amount })] });
  },
};
