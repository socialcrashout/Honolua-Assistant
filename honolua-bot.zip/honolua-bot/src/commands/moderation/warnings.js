const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits } = require('../../utils/permissions');
const { warnListEmbed, errorEmbed } = require('../../components/embeds/moderationEmbeds');
const db = require('../../database/db');

module.exports = {
  name: 'warnings',
  category: 'moderation',
  description: "View a member's warning history.",
  aliases: ['warns'],
  requiredPermission: PermissionFlagsBits.ModerateMembers,
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription("View a member's warning history.")
    .addUserOption((o) => o.setName('user').setDescription('Member to check').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(ctx) {
    const target = await ctx.getTargetMember('user', 0);
    if (!target) return ctx.reply({ embeds: [errorEmbed('Could not find that member.')] });

    const warnings = db.getWarnings(ctx.guild.id, target.id);
    return ctx.reply({ embeds: [warnListEmbed(target.user, warnings)] });
  },
};
