const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits, canModerate } = require('../../utils/permissions');
const { moderationActionEmbed, errorEmbed } = require('../../components/embeds/moderationEmbeds');

module.exports = {
  name: 'ban',
  category: 'moderation',
  description: 'Ban a member from the server.',
  aliases: [],
  requiredPermission: PermissionFlagsBits.BanMembers,
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server.')
    .addUserOption((o) => o.setName('user').setDescription('Member to ban').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Reason for the ban').setRequired(false))
    .addIntegerOption((o) =>
      o.setName('delete_days').setDescription('Delete this many days of their messages (0-7)').setMinValue(0).setMaxValue(7),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(ctx) {
    const target = await ctx.getTargetMember('user', 0);
    if (!target) return ctx.reply({ embeds: [errorEmbed('Could not find that member.')] });

    const check = canModerate(ctx.member, target);
    if (!check.ok) return ctx.reply({ embeds: [errorEmbed(check.reason)] });

    if (!target.bannable) {
      return ctx.reply({ embeds: [errorEmbed("I don't have permission to ban that member.")] });
    }

    const reason = ctx.getReasonOrString('reason', 1);
    const deleteDays = ctx.isSlash ? ctx.getIntegerOption('delete_days', -1) || 0 : 0;

    await target.ban({ reason, deleteMessageSeconds: deleteDays * 24 * 60 * 60 });

    return ctx.reply({
      embeds: [moderationActionEmbed({ action: '🔨 Member Banned', target: target.user, moderator: ctx.user, reason })],
    });
  },
};
