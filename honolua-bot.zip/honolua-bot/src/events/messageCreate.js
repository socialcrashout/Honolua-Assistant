const config = require('../config');
const { CommandContext } = require('../utils/CommandContext');
const { errorEmbed } = require('../components/embeds/moderationEmbeds');

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();

    const resolvedName = client.commands.has(commandName) ? commandName : client.aliases.get(commandName);
    const command = client.commands.get(resolvedName);
    if (!command) return;

    if (command.requiredPermission && !message.member.permissions.has(command.requiredPermission)) {
      return message.reply({ embeds: [errorEmbed("You don't have permission to use that command.")] });
    }

    const ctx = new CommandContext({ message, args, client });

    try {
      await command.execute(ctx);
    } catch (err) {
      console.error(`[messageCreate] Error running command "${commandName}":`, err);
      message.reply({ embeds: [errorEmbed('Something went wrong running that command.')] }).catch(() => {});
    }
  },
};
