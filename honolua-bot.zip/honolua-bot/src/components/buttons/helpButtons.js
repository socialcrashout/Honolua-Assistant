const { ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');

function helpCategoryRow(actorId) {
  const menu = new StringSelectMenuBuilder()
    .setCustomId(`help_select_${actorId}`)
    .setPlaceholder('Browse a command category...')
    .addOptions(
      { label: 'Game', description: 'Restaurant economy commands', value: 'game', emoji: '🍽️' },
      { label: 'Moderation', description: 'Mod-only server management', value: 'moderation', emoji: '🛡️' },
      { label: 'Utility', description: 'Info and general-purpose commands', value: 'utility', emoji: '🔧' },
    );
  return new ActionRowBuilder().addComponents(menu);
}

module.exports = { helpCategoryRow };
