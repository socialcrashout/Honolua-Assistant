const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database/db');
const config = require('../../config');
const { workEmbed, cooldownEmbed } = require('../../components/embeds/gameEmbeds');
const { timeUntil } = require('../../utils/formatters');
const { getItem } = require('../../data/shopItems');

const WORK_LINES = [
  'You grilled up a perfect plate of huli huli chicken.',
  'A tour bus just emptied out and you served them all solo.',
  'Your poke bowl got a 5-star review on the spot.',
  'You restocked the shave ice machine just in time for the rush.',
  'A local auntie said your spam musubi reminded her of home.',
  'You closed out the lunch rush without a single complaint.',
];

module.exports = {
  name: 'work',
  category: 'game',
  description: 'Work a shift at Honolua to earn doubloons.',
  aliases: ['shift'],
  data: new SlashCommandBuilder().setName('work').setDescription('Work a shift at Honolua to earn doubloons.'),

  async execute(ctx) {
    const userData = db.getUser(ctx.guild.id, ctx.user.id);
    const now = Date.now();
    const nextAvailable = userData.lastWork + config.game.workCooldownMs;

    if (now < nextAvailable) {
      const remaining = timeUntil(nextAvailable);
      return ctx.reply({ embeds: [cooldownEmbed(remaining, 'work another shift')] });
    }

    // Upgrades purchased in the shop boost work earnings.
    let bonus = 0;
    for (const [itemId, qty] of Object.entries(userData.inventory || {})) {
      const item = getItem(itemId);
      if (item?.workBonus) bonus += item.workBonus * qty;
    }

    const base = Math.floor(Math.random() * (config.game.workMax - config.game.workMin + 1)) + config.game.workMin;
    const earned = base + bonus;

    const updated = db.updateUser(ctx.guild.id, ctx.user.id, (u) => ({
      ...u,
      balance: u.balance + earned,
      totalEarned: u.totalEarned + earned,
      lastWork: now,
    }));

    const line = WORK_LINES[Math.floor(Math.random() * WORK_LINES.length)];
    return ctx.reply({ embeds: [workEmbed({ user: updated, earned, line })] });
  },
};
