module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(`🌺 Honolua is online as ${client.user.tag} (serving ${client.guilds.cache.size} servers)`);
    client.user.setPresence({
      activities: [{ name: 'orders at Honolua 🌴', type: 3 }], // type 3 = Watching
      status: 'online',
    });
  },
};
