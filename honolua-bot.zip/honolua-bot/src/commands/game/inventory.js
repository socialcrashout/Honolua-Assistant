const { SlashCommandBuilder } = require('discord.js');
const db = require('../../database/db');
const { inventoryEmbed } = require('../../components/embeds/gameEmbeds');

module.exports = {
  name: 'inventory',
  category: 'game',
  description: 'View the dishes and upgrades you own.',
  aliases: ['inv', 'bag'],
  data: new SlashCommandBuilder()
    .setName('inventory')
    .setDescription('View the dishes and upgrades you own.')
    .addUserOption((o) => o.setName('user').setDescription('Member to check (defaults to you)').setRequired(false)),

  async execute(ctx) {
    const member = await ctx.getTargetMember('user', 0);
    const target = member?.user || ctx.user;
    const userData = db.getUser(ctx.guild.id, target.id);
    return ctx.reply({ embeds: [inventoryEmbed(target, userData)] });
  },
};
