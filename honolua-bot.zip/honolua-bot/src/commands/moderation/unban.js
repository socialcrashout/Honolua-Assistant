const { SlashCommandBuilder } = require('discord.js');
const { PermissionFlagsBits } = require('../../utils/permissions');
const { baseEmbed } = require('../../components/embeds/baseEmbed');
const { errorEmbed } = require('../../components/embeds/moderationEmbeds');
const config = require('../../config');

module.exports = {
  name: 'unban',
  category: 'moderation',
  description: 'Unban a user by their ID.',
  aliases: [],
  requiredPermission: PermissionFlagsBits.BanMembers,
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by their ID.')
    .addStringOption((o) => o.setName('user_id').setDescription('The user ID to unban').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(ctx) {
    const userId = ctx.getStringOption('user_id', 0);
    if (!userId || !/^\d{15,22}$/.test(userId)) {
      return ctx.reply({ embeds: [errorEmbed('Provide a valid user ID to unban.')] });
    }

    try {
      await ctx.guild.bans.remove(userId);
    } catch (err) {
      return ctx.reply({ embeds: [errorEmbed('That user is not banned, or I lack permission to unban them.')] });
    }

    return ctx.reply({
      embeds: [
        baseEmbed({
          color: config.colors.success,
          title: '✅ User Unbanned',
          description: `<@${userId}> (\`${userId}\`) has been unbanned.`,
        }),
      ],
    });
  },
};
