const { EmbedBuilder } = require('discord.js');
const config = require('../../config');

/**
 * Base embed component. Every embed in the bot should be built
 * through this so branding (color, footer) stays consistent.
 * This intentionally uses the classic EmbedBuilder API, NOT the
 * newer Components V2 system - keeps things simple and stable.
 */
function baseEmbed({ color = config.colors.primary, title, description } = {}) {
  const embed = new EmbedBuilder()
    .setColor(color)
    .setFooter({ text: '🌺 Honolua' })
    .setTimestamp();

  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  return embed;
}

module.exports = { baseEmbed };
