const { baseEmbed } = require('./baseEmbed');
const config = require('../../config');

function moderationActionEmbed({ action, target, moderator, reason, extra }) {
  const embed = baseEmbed({
    color: config.colors.danger,
    title: `${action}`,
  }).addFields(
    { name: 'User', value: `${target.tag ?? target.user?.tag} (${target.id ?? target.user?.id})`, inline: true },
    { name: 'Moderator', value: `${moderator.tag}`, inline: true },
    { name: 'Reason', value: reason || 'No reason provided.' },
  );
  if (extra) embed.addFields({ name: 'Details', value: extra });
  return embed;
}

function warnListEmbed(target, warnings) {
  const embed = baseEmbed({
    color: config.colors.warning,
    title: `Warnings for ${target.tag}`,
  });
  if (!warnings.length) {
    embed.setDescription('This user has no warnings. Clean record! 🌺');
    return embed;
  }
  warnings.forEach((w, i) => {
    embed.addFields({
      name: `#${i + 1} — ${new Date(w.timestamp).toLocaleString()}`,
      value: `By **${w.moderatorTag}**: ${w.reason}`,
    });
  });
  return embed;
}

function errorEmbed(message) {
  return baseEmbed({ color: config.colors.danger, title: '❌ Error', description: message });
}

module.exports = { moderationActionEmbed, warnListEmbed, errorEmbed };
