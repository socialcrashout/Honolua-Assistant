const db = require('../database/db');
const { getItem } = require('../data/shopItems');

/**
 * Returns { ok: true, item, user } on success, or { ok: false, reason }.
 * Shared between the /buy command and the shop select-menu interaction
 * so both code paths can't drift out of sync.
 */
function purchaseItem(guildId, userId, itemId) {
  const item = getItem(itemId);
  if (!item) return { ok: false, reason: `No item called \`${itemId}\` in the shop.` };

  const userData = db.getUser(guildId, userId);
  if (userData.balance < item.price) {
    return { ok: false, reason: `You need ${item.price} doubloons but only have ${userData.balance}.` };
  }

  const updated = db.updateUser(guildId, userId, (u) => {
    const inventory = { ...(u.inventory || {}) };
    inventory[item.id] = (inventory[item.id] || 0) + 1;
    return { ...u, balance: u.balance - item.price, inventory };
  });

  return { ok: true, item, user: updated };
}

module.exports = { purchaseItem };
