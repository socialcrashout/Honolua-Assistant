/**
 * Wraps either a ChatInputCommandInteraction (slash) or a Message
 * (prefix command) into one consistent `ctx` object. This is what
 * lets every command file in /commands have ONE execute(ctx)
 * function instead of duplicating logic for slash vs prefix.
 */
class CommandContext {
  constructor({ interaction = null, message = null, args = [], client }) {
    this.interaction = interaction;
    this.message = message;
    this.isSlash = Boolean(interaction);
    this.args = args;
    this.client = client;

    this.guild = interaction ? interaction.guild : message.guild;
    this.channel = interaction ? interaction.channel : message.channel;
    this.member = interaction ? interaction.member : message.member;
    this.user = interaction ? interaction.user : message.author;
  }

  /** Reply with an embed/components payload, works for both modes. */
  async reply(payload) {
    if (this.isSlash) {
      if (this.interaction.deferred || this.interaction.replied) {
        return this.interaction.editReply(payload);
      }
      return this.interaction.reply(payload);
    }
    return this.message.reply(payload);
  }

  async deferReply() {
    if (this.isSlash) {
      return this.interaction.deferReply();
    }
    // Prefix commands don't need deferring; no-op for parity.
    return null;
  }

  /**
   * Resolves a "target user" option/argument the same way for both
   * modes. For slash commands this reads the named option; for
   * prefix commands it reads a mention or ID from args[index].
   */
  async getTargetMember(optionName = 'user', argIndex = 0) {
    let user;
    if (this.isSlash) {
      user = this.interaction.options.getUser(optionName);
    } else {
      const raw = this.args[argIndex];
      if (!raw) return null;
      const id = raw.replace(/[<@!>]/g, '');
      user = await this.client.users.fetch(id).catch(() => null);
    }
    if (!user) return null;
    const member = await this.guild.members.fetch(user.id).catch(() => null);
    return member;
  }

  /** Gets a string option (slash) or remaining args joined (prefix). */
  getReasonOrString(optionName = 'reason', fromArgIndex = 1) {
    if (this.isSlash) {
      return this.interaction.options.getString(optionName) || 'No reason provided.';
    }
    const rest = this.args.slice(fromArgIndex).join(' ');
    return rest || 'No reason provided.';
  }

  getStringOption(optionName, argIndex) {
    if (this.isSlash) {
      return this.interaction.options.getString(optionName);
    }
    return this.args[argIndex];
  }

  getIntegerOption(optionName, argIndex) {
    if (this.isSlash) {
      return this.interaction.options.getInteger(optionName);
    }
    const val = parseInt(this.args[argIndex], 10);
    return Number.isNaN(val) ? null : val;
  }
}

module.exports = { CommandContext };
