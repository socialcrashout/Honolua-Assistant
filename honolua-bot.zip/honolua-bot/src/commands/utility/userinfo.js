const { SlashCommandBuilder } = require('discord.js');
const { userInfoEmbed } = require('../../components/embeds/utilityEmbeds');

module.exports = {
  name: 'userinfo',
  category: 'utility',
  description: 'View information about a member.',
  aliases: ['whois', 'user'],
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('View information about a member.')
    .addUserOption((o) => o.setName('user').setDescription('Member to look up (defaults to you)').setRequired(false)),

  async execute(ctx) {
    let member = await ctx.getTargetMember('user', 0);
    let user = member?.user;
    if (!user) {
      user = ctx.user;
      member = ctx.member;
    }
    return ctx.reply({ embeds: [userInfoEmbed(member, user)] });
  },
};
